<?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>


<!-- SECTIONS -->
<section id="home" class="center">
    <p class="logo">bakulic</p>
    <div class="container"> </div>
   <img src="img/logo.png" alt="Imagen" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1;  height: 40%;">
</section>

<section id="about" class="center">
    <div class="container mb-100">
        <div class="row justify-content-center mt-5 header-container">
            <div class="col-lg-6">
                <h1>Nuestra Cocina</h1>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card custom-card text-center">
                    <div class="card-body">
                        <h5 class="card-title custom-title">BAKULIC</h5>
                        <p class="card-text custom-text">
                            Ubicado junto a la serena costa, Bakulic es un oasis culinario de excelencia. Con una vista panorámica del mar, este restaurante ofrece una experiencia gastronómica única. Su variada carta, compuesta por creaciones de autor, fusiona sabores locales e internacionales con maestría. Desde delicias marinas frescas hasta exquisitas carnes y opciones vegetarianas, cada plato es una obra de arte culinaria. Bakulic invita a deleitarse con sabores innovadores en un ambiente relajado y sofisticado. Sumérgete en la esencia de la cocina de autor al borde del océano en Bakulic.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="skills" class="center">
    <div class="container mt-4">
        <div class="row">
            <h1 class="text-center mt-5">Novedades</h1>
            <div class="video-container">
                <div class="col-md-4 mb-4">
                    <video controls loop muted autoplay playsinline style="width: 100%; display: block; margin-bottom: 5px;">
                        <source src="video/menu1.mp4" type="video/mp4"/>
                        Tu navegador no soporta el elemento de video.
                    </video>
                </div>

                <div class="col-md-4 mb-4">
                    <video controls loop muted autoplay playsinline style="width: 100%; display: block; margin-bottom: 5px;">
                        <source src="video/menu2.mp4" type="video/mp4"/>
                        Tu navegador no soporta el elemento de video.
                    </video>
                </div>

                <div class="col-md-4 mb-4">
                    <video controls loop muted autoplay playsinline style="width: 100%; display: block; margin-bottom: 5px;">
                        <source src="video/menu3.mp4" type="video/mp4"/>
                        Tu navegador no soporta el elemento de video.
                    </video>
                </div>
            </div>
        </div>



    </div>
</section>


<section id="projects" class="center">
<div class="container formulario-reserva mt-4 mb-6">
        <h2 class="mt-3">Reserva de Mesa</h2>
        <p>Por favor, complete el siguiente formulario para realizar su reserva:</p>
        <form action="procesar_reserva.php" method="post">
            <div class="form-group">
                <label for="nombre">Nombre:</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="apellido">Apellido:</label>
                <input type="text" class="form-control" id="apellido" name="apellido" required>
            </div>
            <div class="form-group">
                <label for="fecha">Fecha de la reserva:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" required>
            </div>
            <div class="form-group">
                <label for="personas">Número de personas:</label>
                <input type="number" class="form-control" id="personas" name="personas" min="1" required>
            </div>
            <div class="form-group">
                <label for="mensaje">Necesidades especiales o mensaje adicional:</label>
                <textarea class="form-control" id="mensaje" name="mensaje" rows="4" cols="50"></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-lg">Enviar</button>
        </form>
    </div>

</section>


<section id="contact" class="center">
    <div class="container mt-4">
        <div class="row">
            <h1 class="text-center mt-5">Ubicacion</h1>
        </div>
        <div class="row">
            <div class="col-md-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3457.3531939665254!2d-71.28955398716053!3d-29.940517826363692!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9691ca2a1455e717%3A0xf763a902ba3cc888!2sRestaurant%20Bakulic!5e0!3m2!1ses-419!2scl!4v1712689833286!5m2!1ses-419!2scl" width="100%" height="600" style="border-radius: 10px; border: 5px solid white;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('css'); ?>
<style>
        .formulario-reserva {
            max-width: 1200px;
            border: 2px solid white;
            border-radius: 15px;
            padding: 20px;
            margin-top: 50px;
        }
        .form-control {
            height: 50px;
        }

        textarea.form-control {
            height: 150px;
        }

/* tarjeta de menu */
    .custom-card {
    background-color: transparent; /* Cambia el color de fondo a transparente */
    color: #fff;
    border: 5px solid #fff; /* Añade un borde blanco de 5px */
    border-radius: 20px; /* Ajusta el radio de borde según sea necesario */
}

.custom-title {
    font-size: 24px;
    font-weight: bold;
}

.custom-text {
    font-size: 18px;
}

.header-container {
    text-align: center;
    margin-bottom: 20px;
}

  /* Estilos personalizados */
  .video-container {
    display: flex;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    overflow: hidden;
}

.video-container .col-md-4 {
    flex: 1;
    margin: 0;
}

@media (max-width: 767.98px) {
    .video-container .col-md-4 {
        flex: 100%;
    }
}

        .video-container video {
            width: 30%;
            /* Ajusta el ancho según tus necesidades */
            height: auto;
        }
        


/***********************/
/* SECTION */
/***********************/

    
section {
    width: 100%;
    height: 110vh; /* Fallback for browsers that do not support vh units */
    height: 130svh; /* Fallback for browsers that do not support svh units */
    position: relative;
    text-transform: uppercase;
    letter-spacing: 0.2rem;
    text-align: center;
    color: #fff;
}

/* Responsive Styles */
@media screen and (max-width: 768px) {
    section {
        font-size: 14px; /* Adjust font size for smaller screens */
    }
}

@media screen and (max-width: 480px) {
    section {
        font-size: 12px; /* Further adjust font size for even smaller screens */
    }
}
.logo {
    position: fixed;
    z-index: 2;
    top: 1.5rem;
    left: 1.5rem;
    font-size: 1.4rem;
    letter-spacing: 0.3rem;
}

h1 {
    font-size: 3rem;
    background-color: rgb(0, 0, 0, 0.6);
    padding: 0.5rem 1rem;
}

section#home {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("img/bg.jpeg")
        no-repeat center center / cover;
}

section#about {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("img/bg2.jpg")
        no-repeat center center / cover;
}

section#skills {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("img/bg3.jpg")
        no-repeat center center / cover;
}

section#projects {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("img/bg.jpeg")
        no-repeat center center / cover;
}

section#contact {
    background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("img/bg4.jpg")
        no-repeat center center / cover;
}


</style>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('javascript'); ?>

<script>    

var video = document.getElementById('myVideo');
        video.controls = false;
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bakulic\resources\views/welcome.blade.php ENDPATH**/ ?>