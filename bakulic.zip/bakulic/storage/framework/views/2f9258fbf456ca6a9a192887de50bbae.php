<script src="https://cdn03.jotfor.ms/static/prototype.forms.js?v=3.3.52997" type="text/javascript"></script>
<script src="https://cdn01.jotfor.ms/static/jotform.forms.js?v=3.3.52997" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/js/vendor/maskedinput_5.0.9.min.js?v=3.3.52997" type="text/javascript"></script>
<script src="https://cdn03.jotfor.ms/js/punycode-1.4.1.min.js?v=3.3.52997" type="text/javascript" defer></script>
<script src="https://cdn01.jotfor.ms/s/umd/0ff8d3bf4b0/for-appointment-field.js?v=3.3.52997" type="text/javascript"></script>
<script src="https://cdn01.jotfor.ms/s/umd/0ff8d3bf4b0/for-form-branding-footer.js?v=3.3.52997" type="text/javascript" defer></script>
<script src="https://cdn01.jotfor.ms/js/vendor/smoothscroll.min.js?v=3.3.52997" type="text/javascript"></script>
<script src="https://cdn02.jotfor.ms/js/errorNavigation.js?v=3.3.52997" type="text/javascript"></script>
<script type="text/javascript">	JotForm.newDefaultTheme = true;
	JotForm.extendsNewTheme = false;
	JotForm.singleProduct = false;
	JotForm.newPaymentUIForNewCreatedForms = true;
	JotForm.texts = {"confirmEmail":"E-mail does not match","pleaseWait":"Please wait...","validateEmail":"You need to validate this e-mail","confirmClearForm":"Are you sure you want to clear the form","lessThan":"Your score should be less than or equal to","incompleteFields":"There are incomplete required fields. Please complete them.","required":"This field is required.","requireOne":"At least one field required.","requireEveryRow":"Every row is required.","requireEveryCell":"Every cell is required.","email":"Enter a valid e-mail address","alphabetic":"This field can only contain letters","numeric":"This field can only contain numeric values","alphanumeric":"This field can only contain letters and numbers.","cyrillic":"This field can only contain cyrillic characters","url":"This field can only contain a valid URL","currency":"This field can only contain currency values.","fillMask":"Field value must fill mask.","uploadExtensions":"You can only upload following files:","noUploadExtensions":"File has no extension file type (e.g. .txt, .png, .jpeg)","uploadFilesize":"File size cannot be bigger than:","uploadFilesizemin":"File size cannot be smaller than:","gradingScoreError":"Score total should only be less than or equal to","inputCarretErrorA":"Input should not be less than the minimum value:","inputCarretErrorB":"Input should not be greater than the maximum value:","maxDigitsError":"The maximum digits allowed is","minCharactersError":"The number of characters should not be less than the minimum value:","maxCharactersError":"The number of characters should not be more than the maximum value:","freeEmailError":"Free email accounts are not allowed","minSelectionsError":"The minimum required number of selections is ","maxSelectionsError":"The maximum number of selections allowed is ","pastDatesDisallowed":"Date must not be in the past.","dateLimited":"This date is unavailable.","dateInvalid":"This date is not valid. The date format is {format}","dateInvalidSeparate":"This date is not valid. Enter a valid {element}.","ageVerificationError":"You must be older than {minAge} years old to submit this form.","multipleFileUploads_typeError":"{file} has invalid extension. Only {extensions} are allowed.","multipleFileUploads_sizeError":"{file} is too large, maximum file size is {sizeLimit}.","multipleFileUploads_minSizeError":"{file} is too small, minimum file size is {minSizeLimit}.","multipleFileUploads_emptyError":"{file} is empty, please select files again without it.","multipleFileUploads_uploadFailed":"File upload failed, please remove it and upload the file again.","multipleFileUploads_onLeave":"The files are being uploaded, if you leave now the upload will be cancelled.","multipleFileUploads_fileLimitError":"Only {fileLimit} file uploads allowed.","dragAndDropFilesHere_infoMessage":"Drag and drop files here","chooseAFile_infoMessage":"Choose a file","maxFileSize_infoMessage":"Max. file size","generalError":"There are errors on the form. Please fix them before continuing.","generalPageError":"There are errors on this page. Please fix them before continuing.","wordLimitError":"Too many words. The limit is","wordMinLimitError":"Too few words.  The minimum is","characterLimitError":"Too many Characters.  The limit is","characterMinLimitError":"Too few characters. The minimum is","ccInvalidNumber":"Credit Card Number is invalid.","ccInvalidCVC":"CVC number is invalid.","ccInvalidExpireDate":"Expire date is invalid.","ccInvalidExpireMonth":"Expiration month is invalid.","ccInvalidExpireYear":"Expiration year is invalid.","ccMissingDetails":"Please fill up the credit card details.","ccMissingProduct":"Please select at least one product.","ccMissingDonation":"Please enter numeric values for donation amount.","disallowDecimals":"Please enter a whole number.","restrictedDomain":"This domain is not allowed","ccDonationMinLimitError":"Minimum amount is {minAmount} {currency}","requiredLegend":"All fields marked with * are required and must be filled.","geoPermissionTitle":"Permission Denied","geoPermissionDesc":"Check your browser's privacy settings.","geoNotAvailableTitle":"Position Unavailable","geoNotAvailableDesc":"Location provider not available. Please enter the address manually.","geoTimeoutTitle":"Timeout","geoTimeoutDesc":"Please check your internet connection and try again.","selectedTime":"Selected Time","formerSelectedTime":"Former Time","cancelAppointment":"Cancel Appointment","cancelSelection":"Cancel Selection","noSlotsAvailable":"No slots available","slotUnavailable":"{time} on {date} has been selected is unavailable. Please select another slot.","multipleError":"There are {count} errors on this page. Please correct them before moving on.","oneError":"There is {count} error on this page. Please correct it before moving on.","doneMessage":"Well done! All errors are fixed.","invalidTime":"Enter a valid time","doneButton":"Done","reviewSubmitText":"Review and Submit","nextButtonText":"Next","prevButtonText":"Previous","seeErrorsButton":"See Errors","notEnoughStock":"Not enough stock for the current selection","notEnoughStock_remainedItems":"Not enough stock for the current selection ({count} items left)","soldOut":"Sold Out","justSoldOut":"Just Sold Out","selectionSoldOut":"Selection Sold Out","subProductItemsLeft":"({count} items left)","startButtonText":"START","submitButtonText":"Submit","submissionLimit":"Sorry! Only one entry is allowed. Multiple submissions are disabled for this form.","reviewBackText":"Back to Form","seeAllText":"See All","progressMiddleText":"of","fieldError":"field has an error.","error":"Error"};
	JotForm.newPaymentUI = true;
	JotForm.replaceTagTest = true;

   JotForm.setConditions([{"action":[{"id":"action_1705924174516","visibility":"Show","isError":false,"field":"11"}],"id":"1705924203680","index":"0","isError":"1","link":"Any","priority":"0","terms":[{"id":"term_1705924174516","field":"10","operator":"equals","value":"Sí","isError":false}],"type":"field"}]);	JotForm.clearFieldOnHide="disable";
	JotForm.submitError="jumpToFirstError";
	window.addEventListener('DOMContentLoaded',function(){window.brandingFooter.init({"formID":240935781291664,"campaign":"powered_by_jotform_le","isCardForm":false,"isLegacyForm":true})});	JotForm.isFullSource = true;

      try{
        var isEUDomain = /(?:eu.jotform)|(?:jotformeu.com)/.test(window.location.host);
        var isHipaaDomain = /(?:hipaa.jotform)/.test(window.location.host);
        var isProhibitedParameterExists = /(?:wfTaskID|PCI_preSubmitRequest|wfTaskType)/.test(window.location.search);
        var isEditMode = JotForm.isEditMode();
        if (!isEUDomain && !isHipaaDomain && !isProhibitedParameterExists && !isEditMode) {
          var sesApiUrl = /jotform.pro/.test(window.location.host) ? '/API' : 'https://api.jotform.com';
          function sendOpenId(uuid, eventType) {
            navigator.sendBeacon(sesApiUrl + '/form/' + 240935781291664 + '/event/' + uuid + '/' + eventType, {});
          }
          var formOpenId = '';
          if (window.crypto) {
            formOpenId = window.crypto.getRandomValues(new BigUint64Array(1)).toString();
          } else {
            formOpenId = (Math.random() * 16).toString(16).slice(2);
          }
          sendOpenId = sendOpenId.bind(this, formOpenId);
          function sendOpenIdOnSubmit() {
            var currentForm = $('240935781291664');
            currentForm.addEventListener('submit', function() { sendOpenId('clientSubmitClick_V5'); });
            var openIdInput = currentForm.querySelector('[name="formOpenId_V5"]');
            if (!openIdInput) {
              openIdInput = document.createElement('input');
              openIdInput.setAttribute('type', 'hidden');
              openIdInput.setAttribute('name', 'formOpenId_V5');
              currentForm.appendChild(openIdInput);
            }
            openIdInput.value = formOpenId;
          }
          sendOpenId('clientFormView_V5');
          if (document.readyState == 'complete' || (this.jsForm && (document.readyState === undefined || document.readyState === 'interactive'))) {
              sendOpenIdOnSubmit();
          } else {
              document.ready(sendOpenIdOnSubmit);
          }
        }
      } catch(openIdBlockError) {
        console.log(openIdBlockError);
      }
    
	JotForm.init(function(){
	/*INIT-START*/

    JotForm.calendarMonths = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
    JotForm.appointmentCalendarMonths = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
    JotForm.appointmentCalendarDays = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"];
    JotForm.calendarOther = "Today";
    window.initializeAppointment({"text":{"text":"Question","value":"Agenda"},"labelAlign":{"text":"Label Align","value":"Top","dropdown":[["Auto","Auto"],["Left","Left"],["Right","Right"],["Top","Top"]]},"required":{"text":"Required","value":"No","dropdown":[["No","No"],["Yes","Yes"]]},"description":{"text":"Hover Text","value":"","textarea":true},"slotDuration":{"text":"Slot Duration","value":"60","dropdown":[[15,"15 min"],[30,"30 min"],[45,"45 min"],[60,"60 min"],["custom","Custom min"]],"hint":"Select how long each slot will be."},"startDate":{"text":"Start Date","value":""},"endDate":{"text":"End Date","value":""},"intervals":{"text":"Intervals","value":[{"from":"09:00","to":"17:00","days":["Mon","Tue","Wed","Thu","Fri"]}],"hint":"The hours will be applied to the selected days and repeated."},"useBlockout":{"text":"Blockout Custom Dates","value":"No","dropdown":[["No","No"],["Yes","Yes"]],"hint":"Disable certain date(s) in the calendar."},"blockoutDates":{"text":"Blockout dates","value":[{"startDate":"","endDate":""}]},"useLunchBreak":{"text":"Lunch Time","value":"Yes","dropdown":[["No","No"],["Yes","Yes"]],"hint":"Enable lunchtime in the calendar."},"lunchBreak":{"text":"Lunchtime hours","value":[{"from":"12:00","to":"14:00"}]},"timezone":{"text":"Timezone","value":"Europe\u002FIstanbul (GMT+03:00)"},"timeFormat":{"text":"Time Format","value":"24 Hour","dropdown":[["24 Hour","24 Hour"],["AM\u002FPM","AM\u002FPM"]],"icon":"images\u002Fblank.gif","iconClassName":"toolbar-time_format_24"},"months":{"value":["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"],"hidden":true},"days":{"value":["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"],"hidden":true},"startWeekOn":{"text":"Start Week On","value":"Sunday","dropdown":[["Monday","Monday"],["Sunday","Sunday"]],"toolbar":false},"rollingDays":{"text":"Rolling Days","value":"","toolbar":false},"prevMonthButtonText":{"text":"Previous month","value":""},"nextMonthButtonText":{"text":"Next month","value":""},"prevYearButtonText":{"text":"Previous year","value":""},"nextYearButtonText":{"text":"Next year","value":""},"prevDayButtonText":{"text":"Previous day","value":""},"nextDayButtonText":{"text":"Next day","value":""},"appointmentType":{"hidden":true,"value":"single"},"autoDetectTimezone":{"hidden":true,"value":"Yes"},"dateFormat":{"hidden":true,"value":"mm\u002Fdd\u002Fyyyy"},"maxAttendee":{"hidden":true,"value":"5"},"minScheduleNotice":{"hidden":true,"value":"3"},"name":{"hidden":true,"value":"agenda"},"order":{"hidden":true,"value":"2"},"qid":{"toolbar":false,"value":"input_3"},"reminderEmails":{"hidden":true,"value":{"schedule":[{"value":"2","unit":"hour"}]}},"type":{"hidden":true,"value":"control_appointment"},"useReminderEmails":{"hidden":true,"value":"No"},"id":{"toolbar":false,"value":"3"},"qname":{"toolbar":false,"value":"q3_agenda"},"cdnconfig":{"CDN":"https:\u002F\u002Fcdn.jotfor.ms\u002F"},"passive":false,"formProperties":{"highlightLine":"Enabled","coupons":false,"useStripeCoupons":false,"taxes":false,"comparePaymentForm":"","paymentListSettings":false,"newPaymentUIForNewCreatedForms":"Yes","formBackground":"#f5fdff","newAppointment":false,"isAutoCompleteEnabled":true},"formID":240935781291664,"isPaymentForm":false,"isOpenedInPortal":false,"isCheckoutForm":false,"isOfflineForms":false,"SSL_URL":"https:\u002F\u002Fwww.jotform.com\u002F","themeVersion":"v2","isEnterprise":false,"environment":"PRODUCTION"});
        JotForm.setPhoneMaskingValidator( 'input_6_full', '\u0028\u0023\u0023\u0023\u0029 \u0023\u0023\u0023\u002d\u0023\u0023\u0023\u0023' );
if (window.JotForm && JotForm.accessible) $('input_11').setAttribute('tabindex',0);
      JotForm.alterTexts({"ageVerificationError":"Debe ser mayor de {minAge} años para enviar este formulario.","alphabetic":"Este campo solo puede contener letras.","alphanumeric":"Este campo solo puede contener letras y números.","cancelAppointment":"Cancelar cita","cancelSelection":"Cancelar selección","ccDonationMinLimitError":"La cantidad mínima es {minAmount} {currency}","ccInvalidCVC":"El número CVC no es válido.","ccInvalidExpireDate":"La fecha de expiración no es válida","ccInvalidExpireMonth":"Expiration month is invalid.","ccInvalidExpireYear":"Expiration year is invalid.","ccInvalidNumber":"El número de su tarjeta de crédito no es válido.","ccMissingDetails":"Please fill up the credit card details.","ccMissingDonation":"Escriba los valores numéricos de la cantidad a donar.","ccMissingProduct":"Por favor seleccione al menos un producto.","characterLimitError":"Demasiados caracteres. El límite es","characterMinLimitError":"Muy pocos caracteres. El mínimum es","chooseAFile_infoMessage":"Elegir un archivo","confirmClearForm":"¿Está seguro que desea limpiar el formulario?","confirmEmail":"El correo electrónico no coincide","currency":"Este campo sólo puede contener valores de moneda.","cyrillic":"Este campo solo puede contener caracteres cirílicos.","dateInvalid":"Esta fecha no es valida. El formato de fecha es {format}","dateInvalidSeparate":"Esta fecha no es válida. Ponga una {element} válida","dateLimited":"Esta fecha no está disponible.","disallowDecimals":"Por favor, introduzca un número entero.","doneButton":"Listo","doneMessage":"Bien hecho! Todos los errores resueltos.","dragAndDropFilesHere_infoMessage":"Arrastre y suelte archivos aquí","email":"Introduzca una dirección e-mail válida","error":"error","fieldError":"El campo tiene un error.","fillMask":"El valor de este campo debe llenar la mascara","formerSelectedTime":"Hora anterior","freeEmailError":"No se permiten cuentas de correo gratuitas","generalError":"Existen errores en el formulario, por favor corríjalos antes de continuar.","generalPageError":"Hay errores en esta página. Por favor, corríjalos antes de continuar.","geoNotAvailableDesc":"Location provider not available. Please enter the address manually.","geoNotAvailableTitle":"Position Unavailable","geoPermissionDesc":"Check your browser's privacy settings.","geoPermissionTitle":"Permission Denied","geoTimeoutDesc":"Please check your internet connection and try again.","geoTimeoutTitle":"Timeout","gradingScoreError":"El puntaje total debería ser sólo \"menos que\" o \"igual que\"","incompleteFields":"Existen campos requeridos incompletos. Por favor complételos.","inputCarretErrorA":"La entrada no debe ser inferior al valor mínimo:","inputCarretErrorB":"La entrada debe ser menor al valor:","justSoldOut":"Se acaba de agotar","lessThan":"Su puntuación debería ser menor o igual que","maxCharactersError":"The number of characters should not be more than the maximum value:","maxDigitsError":"El máximo de dígitos permitido es","maxFileSize_infoMessage":"Máximo tamaño de archivo","maxSelectionsError":"The maximum number of selections allowed is ","minCharactersError":"El número de caracteres no debería ser menos que el valor mínimo:","minSelectionsError":"El número mínimo de opciones obligatorias es","multipleError":"Hay {count} errores en esta página. Favor corregirlos antes de continuar.","multipleFileUploads_emptyError":"El archivo {file} está vacío; por favor, seleccione de nuevo los archivos sin él.","multipleFileUploads_fileLimitError":"Solo se permite subir {fileLimit} archivo(s)","multipleFileUploads_minSizeError":"El archivo {file} es demasiado pequeño, el tamaño mínimo es: {minSizeLimit}.","multipleFileUploads_onLeave":"Se están cargando los archivos, si cierra ahora, se cancelará dicha carga.","multipleFileUploads_sizeError":"El archivo {file} es demasiado grande; el tamaño del archivo no debe superar {sizeLimit}.","multipleFileUploads_typeError":"El archivo {file} posee una extensión no permitida. Solo están permitidas las extensiones {extensions}.","multipleFileUploads_uploadFailed":"Carga de archivo fallida, favor remover y cargar de nuevo.","nextButtonText":"Seguir","noSlotsAvailable":"No hay cupos disponibles","notEnoughStock":"No hay suficientes existencias para la selección actual","notEnoughStock_remainedItems":"No hay suficientes existencias para la selección actual (quedan {count} artículos)","noUploadExtensions":"File has no extension file type (e.g. .txt, .png, .jpeg)","numeric":"Este campo sólo admite valores numéricos.","oneError":"Hay {count} error en esta página. Favor corregirlo antes de continuar.","pastDatesDisallowed":"La fecha debe ser futura","pleaseWait":"Por favor, espere ...","prevButtonText":"Atrás","progressMiddleText":"de","required":"Este campo es obligatorio.","requiredLegend":"Todos los campos marcados con * son obligatorios y deben llenarse.","requireEveryCell":"Se requieren todas las celdas.","requireEveryRow":"Todas las filas son obligatorias.","requireOne":"Al menos un campo obligatorio.","restrictedDomain":"This domain is not allowed","reviewBackText":"Ir al formulario","reviewSubmitText":"Revisar y enviar","seeAllText":"Mostrar todos","seeErrorsButton":"Ver Errores","selectedTime":"Hora seleccionada","selectionSoldOut":"Selección agotada","slotUnavailable":"{time} on {date} has been selected is unavailable. Please select another slot.","soldOut":"Agotado","startButtonText":"COMENZAR","submissionLimit":"Lo sentimos. Sólo se permite una entrada. Los envíos múltiples están deshabilitados para este formulario.","submitButtonText":"Enviar","subProductItemsLeft":"(quedan {count} productos)","uploadExtensions":"Solo puede subir los siguientes archivos:","uploadFilesize":"Tamaño del archivo no puede ser mayor que:","uploadFilesizemin":"Tamañao de archivo no puede ser menos de:","url":"Este campo solo contiene una URL válida.","validateEmail":"Usted necesita validar este e-mail","wordLimitError":"Demasiadas palabras. El límite es","wordMinLimitError":"Muy pocas palabras. El mínimo es"});
	/*INIT-END*/
	});

   setTimeout(function() {
JotForm.paymentExtrasOnTheFly([null,{"name":"heading","qid":"1","text":"Reservas","type":"control_head"},{"name":"submit2","qid":"2","text":"Enviar","type":"control_button"},{"name":"agenda","qid":"3","text":"Agenda","type":"control_appointment"},{"name":"nombre","qid":"4","text":"Nombre","type":"control_fullname"},null,{"name":"numeroDe","qid":"6","text":"Numero de telefono","type":"control_phone"},null,null,{"name":"email","qid":"9","subLabel":"ejemplo@ejemplo.com","text":"Email","type":"control_email"},null,{"mde":"No","name":"mensaje","qid":"11","text":"mensaje","type":"control_textarea","wysiwyg":"Disable"}]);}, 20); 
</script>
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/stylebuilder/static/form-common.css?v=d0f72cd
"/>
<style type="text/css">@media print{*{-webkit-print-color-adjust: exact !important;color-adjust: exact !important;}.form-section{display:inline!important}.form-pagebreak{display:none!important}.form-section-closed{height:auto!important}.page-section{position:initial!important}}</style>
<link type="text/css" rel="stylesheet" href="https://cdn03.jotfor.ms/themes/CSS/5e6b428acc8c4e222d1beb91.css?v=3.3.52997"/>
<link type="text/css" rel="stylesheet" href="https://cdn01.jotfor.ms/css/styles/payment/payment_styles.css?3.3.52997" />
<link type="text/css" rel="stylesheet" href="https://cdn02.jotfor.ms/css/styles/payment/payment_feature.css?3.3.52997" />
<style type="text/css" id="form-designer-style">
    /* Injected CSS Code */
/*PREFERENCES STYLE*/
    .form-all {
      font-family: Inter, sans-serif;
    }
  
    .form-label.form-label-auto {
      
    display: block;
    float: none;
    text-align: left;
    width: 100%;
  
    }
  
    .form-line {
      margin-top: 12px;
      margin-bottom: 12px;
    }
  
    .form-all {
      max-width: 752px;
      width: 100%;
    }
  
    .form-label.form-label-left,
    .form-label.form-label-right,
    .form-label.form-label-left.form-label-auto,
    .form-label.form-label-right.form-label-auto {
      width: 230px;
    }
  
    .form-all {
      font-size: 16px
    }
  
    .supernova .form-all, .form-all {
      background-color: #f5fdff;
    }
  
    .form-all {
      color: #005875;
    }
    .form-header-group .form-header {
      color: #005875;
    }
    .form-header-group .form-subHeader {
      color: #005875;
    }
    .form-label-top,
    .form-label-left,
    .form-label-right,
    .form-html,
    .form-checkbox-item label,
    .form-radio-item label,
    span.FITB .qb-checkbox-label,
    span.FITB .qb-radiobox-label,
    span.FITB .form-radio label,
    span.FITB .form-checkbox label,
    [data-blotid][data-type=checkbox] [data-labelid],
    [data-blotid][data-type=radiobox] [data-labelid],
    span.FITB-inptCont[data-type=checkbox] label,
    span.FITB-inptCont[data-type=radiobox] label {
      color: #005875;
    }
    .form-sub-label {
      color: #1a728f;
    }
  
  .supernova {
    background-color: #367c96;
  }
  .supernova body {
    background: transparent;
  }
  
    .form-textbox,
    .form-textarea,
    .form-dropdown,
    .form-radio-other-input,
    .form-checkbox-other-input,
    .form-captcha input,
    .form-spinner input {
      background-color: #ffffff;
    }
  
    
    .supernova {
      background-repeat: no-repeat;
      background-size:cover;
      background-attachment: fixed;
      background-position: center top;
    }

    .supernova, #stage {
      background-image: url("https://www.jotform.com/uploads/guest_ad3bb8238b261074/form_files/Recibimos_oto%C3%B1o_con_toda_la_esencia_de_uni%C3%B3n_,_atenci%C3%B3n_,_sabor_y_experiencia_que_nos_caracteriza_en_nuestro_para%C3%ADso_gastron%C3%B3mico_Bakul%C3%ADc_%C2%A1Agradecidos_siempre_de_su_preferencia!_@bakulicrestaurant_Avenida%20(1).660db0e60ddc81.26267052.jpg");
    }
      .form-all {
        background-image: none;
      }
    /*PREFERENCES STYLE*//*__INSPECT_SEPERATOR__*/
    /* Injected CSS Code */
</style>

<form class="jotform-form" onsubmit="return typeof testSubmitFunction !== 'undefined' && testSubmitFunction();" action="https://submit.jotform.com/submit/240935781291664" method="post" name="form_240935781291664" id="240935781291664" accept-charset="utf-8" autocomplete="on"><input type="hidden" name="formID" value="240935781291664" /><input type="hidden" id="JWTContainer" value="" /><input type="hidden" id="cardinalOrderNumber" value="" /><input type="hidden" id="jsExecutionTracker" name="jsExecutionTracker" value="build-date-1712173445048" /><input type="hidden" id="submitSource" name="submitSource" value="unknown" /><input type="hidden" id="buildDate" name="buildDate" value="1712173445048" />
  <div id="formCoverLogo" style="margin-bottom:32px" class="form-cover-wrapper form-has-cover form-page-cover-image-align-center">
    <div class="form-page-cover-image-wrapper" style="max-width:752px"><img src="https://www.jotform.com/uploads/guest_ad3bb8238b261074/form_files/Dise%C3%B1o%20sin%20t%C3%ADtulo%20(1)%20(1).660db0cc496d13.03081927.png" class="form-page-cover-image" width="190" aria-label="Form Logo" style="aspect-ratio:190/141" /></div>
  </div>
  <div role="main" class="form-all">
    <ul class="form-section page-section">
      <li id="cid_1" class="form-input-wide" data-type="control_head">
        <div class="form-header-group  header-large">
          <div class="header-text httac htvam">
            <h1 id="header_1" class="form-header" data-component="header">Reservas</h1>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_appointment" id="id_3"><label class="form-label form-label-top" id="label_3" for="input_3" aria-hidden="false"> Agenda </label>
        <div id="cid_3" class="form-input-wide" data-layout="full">
          <div id="input_3" class="appointmentFieldWrapper jfQuestion-fields"><input type="hidden" class="appointmentFieldInput" name="q3_agenda[implementation]" value="new" id="input_3implementation" aria-hidden="true" /><input type="hidden" class="appointmentFieldInput " name="q3_agenda[date]" id="input_3_date" data-timeformat="24 Hour" aria-hidden="true" /><input type="hidden" class="appointmentFieldInput" name="q3_agenda[duration]" value="60" id="input_3_duration" aria-hidden="true" /><input type="hidden" class="appointmentFieldInput" name="q3_agenda[timezone]" value="Europe/Istanbul (GMT+03:00)" id="input_3_timezone" aria-hidden="true" />
            <div class="appointmentField"></div>
          </div>
        </div>
      </li>
      <li class="form-line" data-type="control_fullname" id="id_4"><label class="form-label form-label-top form-label-auto" id="label_4" for="first_4" aria-hidden="false"> Nombre </label>
        <div id="cid_4" class="form-input-wide" data-layout="full">
          <div data-wrapper-react="true"><span class="form-sub-label-container" style="vertical-align:top" data-input-type="first"><input type="text" id="first_4" name="q4_nombre[first]" class="form-textbox" data-defaultvalue="" autoComplete="section-input_4 given-name" size="10" data-component="first" aria-labelledby="label_4 sublabel_4_first" value="" /><label class="form-sub-label" for="first_4" id="sublabel_4_first" style="min-height:13px">Nombre</label></span><span class="form-sub-label-container" style="vertical-align:top" data-input-type="last"><input type="text" id="last_4" name="q4_nombre[last]" class="form-textbox" data-defaultvalue="" autoComplete="section-input_4 family-name" size="15" data-component="last" aria-labelledby="label_4 sublabel_4_last" value="" /><label class="form-sub-label" for="last_4" id="sublabel_4_last" style="min-height:13px">Apellido</label></span></div>
        </div>
      </li>
      <li class="form-line form-line-column form-col-1" data-type="control_phone" id="id_6"><label class="form-label form-label-top form-label-auto" id="label_6" for="input_6_full"> Número de teléfono </label>
        <div id="cid_6" class="form-input-wide" data-layout="half"> <span class="form-sub-label-container" style="vertical-align:top"><input type="tel" id="input_6_full" name="q6_numeroDe[full]" data-type="mask-number" class="mask-phone-number form-textbox validate[Fill Mask]" data-defaultvalue="" autoComplete="section-input_6 tel-national" style="width:310px" data-masked="true" placeholder="(000) 000-0000" data-component="phone" aria-labelledby="label_6 sublabel_6_masked" value="" /><label class="form-sub-label" for="input_6_full" id="sublabel_6_masked" style="min-height:13px">Favor ingrese un número de teléfono válido.</label></span> </div>
      </li>
      <li class="form-line" data-type="control_email" id="id_9"><label class="form-label form-label-top form-label-auto" id="label_9" for="input_9" aria-hidden="false"> Email </label>
        <div id="cid_9" class="form-input-wide" data-layout="half"> <span class="form-sub-label-container" style="vertical-align:top"><input type="email" id="input_9" name="q9_email" class="form-textbox validate[Email]" data-defaultvalue="" autoComplete="section-input_9 email" style="width:310px" size="310" data-component="email" aria-labelledby="label_9 sublabel_input_9" value="" /><label class="form-sub-label" for="input_9" id="sublabel_input_9" style="min-height:13px">ejemplo@ejemplo.com</label></span> </div>
      </li>
      <li class="form-line" data-type="control_textarea" id="id_11"><label class="form-label form-label-top form-label-auto" id="label_11" for="input_11" aria-hidden="false"> mensaje </label>
        <div id="cid_11" class="form-input-wide" data-layout="full"> <textarea id="input_11" class="form-textarea" name="q11_mensaje" style="width:648px;height:163px" data-component="textarea" aria-labelledby="label_11"></textarea> </div>
      </li>
      <li class="form-line" data-type="control_button" id="id_2">
        <div id="cid_2" class="form-input-wide" data-layout="full">
          <div data-align="auto" class="form-buttons-wrapper form-buttons-auto   jsTest-button-wrapperField"><button id="input_2" type="submit" class="form-submit-button submit-button jf-form-buttons jsTest-submitField" data-component="button" data-content="">Enviar</button></div>
        </div>
      </li>
      <li style="display:none">Should be Empty: <input type="text" name="website" value="" type="hidden" /></li>
    </ul>
  </div>
  <script>
    JotForm.showJotFormPowered = "new_footer";
  </script>
  <script>
    
  </script><input type="hidden" class="simple_spc" id="simple_spc" name="simple_spc" value="240935781291664" />
  <script type="text/javascript">
    var all_spc = document.querySelectorAll("form[id='240935781291664'] .si" + "mple" + "_spc");
    for (var i = 0; i < all_spc.length; i++)
    {
      all_spc[i].value = "240935781291664-240935781291664";
    }
  </script>
</form>
<?php /**PATH C:\xampp\htdocs\bakulic\resources\views/layouts/formulario.blade.php ENDPATH**/ ?>