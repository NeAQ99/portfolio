<style>
    /***********************/
/* NAVIGATION MENU */
/***********************/

/* OVERLAY */
.overlay {
    z-index: 9;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    height: 100svh;
    background-color: rgba(0, 0, 0, 0.7);
}

.overlay-slide-right {
    transition: all 0.4s ease-in-out;
    transform: translateX(0);
}

.overlay-slide-left {
    transition: all 0.8s ease-in-out;
    transform: translateX(-100%);
}

/* NAV MENU ITEMS */
nav ul {
    height: 100vh;
    height: 100svh;
    list-style: none;
}

nav ul li {
    height: 20%;
}

nav li:nth-of-type(1) {
    background-color: #626059;
}

nav li:nth-of-type(2) {
    background-color: #9d5543;
}

nav li:nth-of-type(3) {
    background-color: #3d405b;
}

nav li:nth-of-type(4) {
    background-color: #5a7d6c;
}

nav li:nth-of-type(5) {
    background-color: #917a56;
}

nav li a {
    letter-spacing: 0.4rem;
    font-size: 2rem;
}

nav li a:hover,
nav li a:active {
    transform: scale(1.2);
}

/***********************/
/* NAV SLIDE IN ANIMATION */
/***********************/

.slide-in-1 {
    animation: slide-in 0.4s linear 0.2s both;
}

.slide-in-2 {
    animation: slide-in 0.4s linear 0.4s both;
}

.slide-in-3 {
    animation: slide-in 0.4s linear 0.6s both;
}

.slide-in-4 {
    animation: slide-in 0.4s linear 0.8s both;
}

.slide-in-5 {
    animation: slide-in 0.4s linear 1s both;
}

@keyframes slide-in {
    from {
        transform: translateX(-100%);
    }
    to {
        transform: translateX(0);
    }
}

/***********************/
/* NAV SLIDE OUT ANIMATION */
/***********************/

.slide-out-1 {
    animation: slide-out 0.3s linear 0.5s both;
}

.slide-out-2 {
    animation: slide-out 0.3s linear 0.4s both;
}

.slide-out-3 {
    animation: slide-out 0.3s linear 0.3s both;
}

.slide-out-4 {
    animation: slide-out 0.3s linear 0.2s both;
}

.slide-out-5 {
    animation: slide-out 0.3s linear 0.1s both;
}

@keyframes slide-out {
    from {
        transform: translateX(0);
    }
    to {
        transform: translateX(-100%);
    }
}

/***********************/
/* HAMBURGER MENU ANIMATION */
/***********************/

.hamburger-menu {
    position: fixed;
    top: 1rem;
    right: 2rem;
    z-index: 10;
    cursor: pointer;
}

.menu-bar1,
.menu-bar2,
.menu-bar3 {
    width: 3.5rem;
    height: 0.2rem;
    background-color: #fff;
    margin: 0.8rem 0;
    transition: 0.4s;
}

.menu-bar2 {
    width: 2rem;
    margin-left: auto;
}

/* ROTATE FIRST BAR */
.active .menu-bar1 {
    transform: rotate(-45deg) translate(-0.7rem, 0.8rem);
}

/* FADE OUT SECOND BAR */
.active .menu-bar2 {
    opacity: 0;
}

/* ROTATE LAST BAR */
.active .menu-bar3 {
    transform: rotate(45deg) translate(-0.6rem, -0.8rem);
}

html {
    /* 
        font-size: 10px; 
        10px / 16px = 0.625 = 62.5%
        Percentage of user's browser font-size setting
    */
    font-size: 62.5%;
    overflow-x: hidden;
    scroll-behavior: smooth;
}

a:link,
a:visited {
    color: #fff;
    text-decoration: none;
    text-transform: uppercase;
    transition: all 0.3s;
}

/* HELPER CLASSES */
.center {
    display: flex;
    align-items: center;
    justify-content: center;
}

/* For screens smaller than 768px */
@media screen and (max-width: 767px) {
    /* Overlay */
    .overlay {
        background-color: rgba(0, 0, 0, 0.85); /* Darker overlay */
    }

    /* NAV MENU ITEMS */
    nav ul {
        height: auto; /* Adjust height as per content */
    }

    nav li {
        height: auto; /* Adjust height as per content */
    }

    nav li a {
        font-size: 1.8rem; /* Decrease font size */
    }

    /* HAMBURGER MENU */
    .hamburger-menu {
        top: 0.8rem; /* Adjust position */
        right: 1.5rem; /* Adjust position */
    }
}

/* For screens smaller than 480px */
@media screen and (max-width: 479px) {
    /* NAV MENU ITEMS */
    nav li a {
        font-size: 1.6rem; /* Further decrease font size */
    }

    /* HAMBURGER MENU */
    .hamburger-menu {
        top: 0.6rem; /* Further adjust position */
        right: 1rem; /* Further adjust position */
    }
}

</style>

<!-- MENU OVERLAY -->
<div class="overlay overlay-slide-left" id="overlay">
    <!-- MENU ITEMS -->
    <nav>
        <ul>
            <li id="nav-1" class="slide-out-1 center">
                <a href="#home" class="center">inicio</a>
            </li>
            <li id="nav-2" class="slide-out-2 center">
                <a href="#about" class="center">menu</a>
            </li>
            <li id="nav-3" class="slide-out-3 center">
                <a href="#skills" class="center">reservas</a>
            </li>
            <li id="nav-4" class="slide-out-4 center">
                <a href="#projects" class="center">Eventos</a>
            </li>
        </ul>
    </nav>
</div>
  <!-- HAMBURGER MENU -->
<div class="hamburger-menu" id="hamburger-menu">
    <div class="menu-bar1"></div>
    <div class="menu-bar2"></div>
    <div class="menu-bar3"></div>
</div>

<!-- MENU OVERLAY -->
<div class="overlay overlay-slide-left" id="overlay">
    <!-- MENU ITEMS -->
    <nav>
        <ul>
            <li id="nav-1" class="slide-out-1 center">
                <a href="#home" class="center">inicio</a>
            </li>
            <li id="nav-2" class="slide-out-2 center">
                <a href="#about" class="center">menu</a>
            </li>
            <li id="nav-3" class="slide-out-3 center">
                <a href="#skills" class="center">reservas</a>
            </li>
            <li id="nav-4" class="slide-out-4 center">
                <a href="#projects" class="center">Eventos</a>
            </li>
        </ul>
    </nav>
</div>


<script>
    
    const hamburgerMenu = document.querySelector("#hamburger-menu");
    const overlay = document.querySelector("#overlay");
    const nav1 = document.querySelector("#nav-1");
    const nav2 = document.querySelector("#nav-2");
    const nav3 = document.querySelector("#nav-3");
    const nav4 = document.querySelector("#nav-4");
    const nav5 = document.querySelector("#nav-5");
    const navItems = [nav1, nav2, nav3, nav4, nav5];

    // Control Navigation Animation
    function navAnimation(val1, val2) {
    navItems.forEach((nav, i) => {
        nav.classList.replace(`slide-${val1}-${i + 1}`, `slide-${val2}-${i + 1}`);
    });
    }

    function toggleNav() {
    // Toggle: Hamburger Open/Close
    hamburgerMenu.classList.toggle("active");

    //   Toggle: Menu Active
    overlay.classList.toggle("overlay-active");

    if (overlay.classList.contains("overlay-active")) {
        // Animate In - Overlay
        overlay.classList.replace("overlay-slide-left", "overlay-slide-right");

        // Animate In - Nav Items
        navAnimation("out", "in");
    } else {
        // Animate Out - Overlay
        overlay.classList.replace("overlay-slide-right", "overlay-slide-left");

        // Animate Out - Nav Items
        navAnimation("in", "out");
    }
    }

    // Events Listeners
    hamburgerMenu.addEventListener("click", toggleNav);
    navItems.forEach((nav) => {
    nav.addEventListener("click", toggleNav);
    });


</script><?php /**PATH C:\xampp\htdocs\bakulic\resources\views/layouts/top.blade.php ENDPATH**/ ?>