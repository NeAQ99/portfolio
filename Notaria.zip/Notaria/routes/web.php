<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
})->name('/');

Route::get('/servicios', function () {
    return view('servicios');
})->name('servicios');

Route::get('/quienes', function () {
    return view('quienes');
})->name('quienes');

Route::get('/ubicacion', function () {
    return view('ubicacion');
})->name('ubicacion');

Route::get('/contactanos', function () {
    return view('contactanos');
})->name('contactanos');


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
