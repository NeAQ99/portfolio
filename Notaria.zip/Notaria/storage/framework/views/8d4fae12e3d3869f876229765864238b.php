<style>

    .sticky-footer{

        background-color: rgb(36,64,101);
        color:white;

    }

    @media screen and (max-width: 600px) {

        .container.my-auto {

            display: flex;
            flex-direction: column; 
            align-items: center; 
            
        }
    }

</style>

<!-- Footer -->
<footer class="sticky-footer">
    <div class="container my-auto" style="display: flex; justify-content: space-between;">
        <div style="flex: 1; margin: 1em;">
        <p style="text-align: justify; border-bottom: 2px solid rgb(255,255,255); font-size: 1.4em">Dirección</p>
             
            <p style="text-align: justify;">
            Pedro Aguirre Cerda 101<br> 1780000 Coquimbo
                
            </p>
        </div>
        <div style="flex: 1; margin: 1em;">
            <p style="text-align: justify; border-bottom: 2px solid rgb(255,255,255); font-size: 1.4em">Contacto</p> 
            <p style="text-align: justify;">
                Teléfono: (51) 277 5787 <br>
                Correo: contacto@notariapgutierrez.cl
                
            </p>
        </div>
        <div style="flex: 1; margin: 1em;">
            <p style="text-align: justify; border-bottom: 2px solid rgb(255,255,255); font-size: 1.4em">Atención</p> 
            <p style="text-align: justify;">
                Lunes a Viernes: 8:30 a 17:00 hrs. (Continuado)<br>                
                Sábado: 10:00 a 13:00 hrs. (Solo días de turno)
            </p>
        </div>
    </div>
    <div class="container my-auto">
        <table style="width:100%">
            <tr>
                <td>
                    <div class="copyright text-center my-auto">
                        <span style="color:white;">NOTARIA GUTIERREZ, Chile <?php echo e(date("Y")); ?>. Todos los derechos reservados.</span>
                    </div>
                </td>                
            </tr>
        </table>
    </div>
</footer>
<!-- Final de Footer -->
<?php /**PATH C:\xampp\htdocs\Notaria\resources\views/layouts/footer.blade.php ENDPATH**/ ?>