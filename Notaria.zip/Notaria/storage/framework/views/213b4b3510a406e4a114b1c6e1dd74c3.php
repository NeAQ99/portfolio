
<?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>


    <!-- Seccion de boxes 4x2 que contiene los ejemplos de servicios -->

    <!-- <div style="background-color: #ffffff; max-width: 1200px; margin: 50px auto 0 auto;"> -->
    <div id="seccion-de-servicios">
        <div class="container mt-4" style="padding-top: 100px;">
            <div class="row">
                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Testamentos y manejo de herencias</div>
                    <img src="img/testamento.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal1">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Elaboración de poderes de representación</div>
                    <img src="img/representacion.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal2">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Creación de empresas o asociaciones</div>
                    <img src="img/empresa.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal3">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Transacciones de compra y venta de bienes raíces</div>
                    <img src="img/bienes.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal4">Mas Informacion</button>
                </div>
            </div>

            <div class="row" style="padding-top: 50px;">
                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Constitución de hipotecas</div>
                    <img src="img/hipoteca.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal5">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Gestión de fideicomisos</div>
                    <img src="img/fideicomisos.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal6">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Declaraciones juradas</div>
                    <img src="img/declaracion.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal7">Mas Informacion</button>
                </div>

                <div class="col-md-6 col-lg-3 box" style="display: flex; flex-direction: column; align-items: center;">
                    <div class="box-title">Contrato de arrendamiento</div>
                    <img src="img/arrendamiento.png" class="box-icon">
                    <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#modal8">Mas Informacion</button>
                </div>
            </div>
        </div>
    </div>
</div>



    
<!-- Modal 1 -->
<div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal1">Testamentos y manejo de herencias</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                    "Los testamentos y el manejo de herencias son procesos legales que permiten a una persona determinar la distribución de sus bienes y propiedades después de su fallecimiento. Mediante un testamento, se especifican los beneficiarios de dichos bienes, así como los términos y condiciones para su transferencia. El manejo de herencias implica la administración de los activos y pasivos de una persona fallecida, incluyendo la liquidación de deudas y la distribución equitativa de la herencia entre los herederos legales. Estos procedimientos proporcionan seguridad y claridad en la gestión de los asuntos financieros y patrimoniales de una persona tras su partida."
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2 -->
<div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="modal2" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal2">Elaboración de poderes de representación</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                La elaboración de poderes de representación es un proceso legal mediante el cual una persona (llamada poderdante) otorga a otra (llamada apoderado) la autoridad para actuar en su nombre en asuntos específicos o generales. Esta autoridad puede incluir la capacidad de firmar documentos, realizar transacciones financieras, administrar propiedades, o tomar decisiones médicas, entre otros. Los poderes de representación pueden ser útiles en situaciones en las que el poderdante no pueda estar presente personalmente para realizar ciertas acciones legales o administrativas. Es importante entender que el poder otorgado puede ser limitado o amplio, dependiendo de las necesidades y deseos del poderdante, y puede ser revocado en cualquier momento si así lo decide el poderdante. Obtener un poder de representación adecuado puede proporcionar seguridad y protección tanto para el poderdante como para el apoderado en diversas circunstancias legales y personales.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 3-->
<div class="modal fade" id="modal3" tabindex="-1" role="dialog" aria-labelledby="modal3" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal3">Creación de empresas o asociaciones</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                La creación de empresas o asociaciones es un proceso fundamental que implica la formalización legal de una entidad empresarial. Como notario, mi rol consiste en asesorar y guiar a los individuos o grupos interesados en establecer una empresa o asociación. Esto incluye explicar los diferentes tipos de estructuras legales disponibles, como sociedades limitadas, sociedades anónimas o asociaciones sin fines de lucro, y ayudar a seleccionar la más adecuada según sus necesidades y objetivos comerciales. Luego, facilito la redacción y firma de los documentos legales pertinentes, como estatutos, actas constitutivas y registros de socios o miembros. Además, me aseguro de que se cumplan todos los requisitos legales y administrativos necesarios para el registro y la formalización de la empresa o asociación, garantizando así su validez y cumplimiento de las regulaciones locales. En resumen, mi función como notario es facilitar y garantizar un proceso transparente y legalmente sólido para la creación de empresas y asociaciones.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 4 -->
<div class="modal fade" id="modal4" tabindex="-1" role="dialog" aria-labelledby="modal4" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal4">Transacciones de compra y venta de bienes raíces</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                En el contexto de transacciones de compra y venta de bienes raíces, mi función como notario es fundamental para garantizar la legalidad y seguridad de la transacción. Actúo como un intermediario imparcial y objetivo entre el comprador y el vendedor, asegurándome de que todas las partes cumplan con los requisitos legales y financieros necesarios para completar la transacción de manera adecuada.

Mi trabajo incluye la revisión y redacción de contratos de compraventa, así como la verificación de la titularidad y la existencia de cualquier carga o gravamen sobre la propiedad. Además, me encargo de coordinar con las autoridades pertinentes para la inscripción de la propiedad en el registro público y la transferencia legal de la misma al nuevo propietario.

Como notario, también estoy presente en la firma final del contrato de compraventa, donde certifico la identidad de las partes involucradas y garantizo la validez del acuerdo. Mi objetivo es proteger los intereses de ambas partes y asegurar que la transacción se realice de manera justa y transparente, proporcionando así seguridad jurídica y confianza en el proceso de compra y venta de bienes raíces.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 5 -->
<div class="modal fade" id="modal5" tabindex="-1" role="dialog" aria-labelledby="modal5" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal5">Constitución de hipotecas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                   
La constitución de hipotecas es un proceso esencial en el ámbito inmobiliario en el que intervengo como notario para garantizar la validez y seguridad de la transacción. Mi responsabilidad principal es redactar y formalizar el contrato de hipoteca, que establece los términos y condiciones del préstamo asegurado por la propiedad inmueble.

Durante este proceso, verifico la legalidad de la operación, asegurándome de que el prestatario cumpla con los requisitos establecidos por la ley y de que la propiedad a ser hipotecada esté libre de gravámenes o cargas que pudieran afectar la validez del préstamo.

Además, actúo como intermediario entre el prestamista y el prestatario, explicando claramente los términos del contrato y asegurándome de que ambas partes comprendan sus derechos y obligaciones.

Una vez redactado el contrato, superviso la firma de las partes involucradas y me encargo de registrar la hipoteca en el registro público de la propiedad, lo que garantiza la validez y ejecutabilidad del préstamo. En resumen, mi papel como notario en la constitución de hipotecas es facilitar un proceso legal y transparente que proteja los intereses de ambas partes y asegure el cumplimiento de las regulaciones legales vigentes.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 6 -->
<div class="modal fade" id="modal6" tabindex="-1" role="dialog" aria-labelledby="modal6" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal6">Elaboración de poderes de representación</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                La gestión de fideicomisos implica un conjunto de responsabilidades que como notario desempeño para garantizar la correcta administración de los bienes y activos confiados a un fideicomiso. Mi labor comienza al redactar y formalizar el contrato de fideicomiso, en el que se establecen los términos y condiciones bajo los cuales se gestionarán los activos en beneficio de los beneficiarios designados.

En este proceso, mi función incluye asegurarme de que el fideicomiso cumpla con todos los requisitos legales y regulatorios pertinentes, así como de verificar la validez de los documentos relacionados con los activos incluidos en el fideicomiso.

Actúo como intermediario entre el fideicomitente (quien confía los bienes) y el fiduciario (quien administra los activos), garantizando que ambas partes comprendan sus derechos y obligaciones.

Además, superviso la distribución de los activos de acuerdo con las instrucciones establecidas en el contrato de fideicomiso y me aseguro de que se cumplan todas las disposiciones legales aplicables.

En resumen, mi papel en la gestión de fideicomisos es facilitar un proceso transparente y legalmente sólido que proteja los intereses de todas las partes involucradas y asegure el cumplimiento de las disposiciones legales y regulatorias.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 7 -->
<div class="modal fade" id="modal7" tabindex="-1" role="dialog" aria-labelledby="modal7" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal2">Declaraciones juradas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                Las declaraciones juradas son documentos legales en los cuales una persona hace una afirmación sobre un hecho o situación bajo juramento y bajo pena de perjurio. Como notario, mi función en relación con las declaraciones juradas es verificar la identidad del declarante, asegurarme de que comprenda la importancia y las implicaciones legales de su declaración, y luego certificar su firma y juramento.

Además, puedo redactar la declaración jurada según las especificaciones del declarante o las exigencias legales aplicables. Es importante garantizar que la declaración jurada esté redactada de manera precisa y clara, y que contenga toda la información necesaria para respaldar la afirmación realizada.

Una vez que el declarante ha firmado la declaración jurada frente a mí como notario, certifico la autenticidad de la firma y el juramento. Esto proporciona un nivel adicional de credibilidad y legalidad a la declaración, ya que la firma de un notario generalmente se considera una garantía de autenticidad.

En resumen, mi papel como notario en relación con las declaraciones juradas es garantizar la integridad y legalidad del proceso, certificando la autenticidad de la declaración y brindando seguridad jurídica a todas las partes involucradas.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal 8-->
<div class="modal fade" id="modal8" tabindex="-1" role="dialog" aria-labelledby="modal8" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal8">Contrato de arrendamiento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card" style="background-color: #fff7e1; border-radius: 10px; padding: 20px;">
                  
El contrato de arrendamiento es un documento legal que establece los términos y condiciones bajo los cuales una parte (el arrendador) acuerda alquilar un bien inmueble a otra parte (el arrendatario) a cambio de un pago periódico, generalmente conocido como renta. Como notario, mi rol en la elaboración y formalización de un contrato de arrendamiento implica varios pasos.

En primer lugar, verifico la identidad de ambas partes involucradas y me aseguro de que tengan la capacidad legal para celebrar el contrato. Luego, redacto el contrato de arrendamiento, incluyendo todos los términos y condiciones acordados entre el arrendador y el arrendatario, como la duración del arrendamiento, el monto de la renta, las responsabilidades de mantenimiento, entre otros aspectos importantes.

Es fundamental que el contrato de arrendamiento esté redactado de manera clara y precisa para evitar posibles malentendidos o disputas en el futuro. Además, me aseguro de que el contrato cumpla con todas las leyes y regulaciones locales aplicables.

Una vez redactado el contrato, coordino la firma de ambas partes y certifico la autenticidad de sus firmas. Finalmente, registro el contrato de arrendamiento en el registro público de la propiedad, lo que brinda seguridad jurídica a ambas partes y garantiza el cumplimiento de los términos acordados.

En resumen, mi papel como notario en la elaboración de contratos de arrendamiento es facilitar un proceso legal y transparente que proteja los intereses de ambas partes y asegure el cumplimiento de las regulaciones legales pertinentes.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>




<!-- Contenedor que posee la sección de preguntas frecuentes ------------------------------------------------------------------------------>
<div id="QA" class="container mt-5 mb-5" style="padding: 50px; background-color: #ffeb79;">
        <h1 class="mb-5">Preguntas Frecuentes</h1>
        <div class="accordion" id="accordionExample">
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        ¿Qué se requiere para hacer una declaración jurada?
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Es necesario que el declarante concurra personalmente a la notaría con su documento oficial de identificación vigente.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        ¿Cómo puedo otorgar un testamento?
                    </button>
                </h2>
                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Para otorgar un testamento, es necesario acudir a una notaría con un abogado.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        ¿Cómo y cuándo tiene validez en Chile un documento otorgado en el extranjero?
                    </button>
                </h2>
                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Un documento otorgado en el extranjero tiene validez en Chile cuando es legalizado o apostillado, según corresponda.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                        ¿Qué documentos son necesarios para vender un vehículo?
                    </button>
                </h2>
                <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Para vender un vehículo, se necesita el Certificado de Anotaciones Vigentes y de multa del Vehículo, con no más de 2 días de antigüedad, y el último Permiso de Circulación.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                        ¿Qué establece la Ley de Timbres y Estampillas en relación con los impuestos que deben pagar documentos mercantiles como letras de cambio y pagarés?
                    </button>
                </h2>
                <div id="collapseFive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        La Ley de Timbres y Estampillas establece que estos documentos deben estar timbrados para tener validez legal.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                        ¿Qué es una Empresa Individual de Responsabilidad Limitada o E.I.R.L.?
                    </button>
                </h2>
                <div id="collapseSix" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Es una forma de empresa en la que el titular responde con su patrimonio empresarial, pero no con su patrimonio personal.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                        ¿Qué se necesita para transferir un bien raíz por compraventa?
                    </button>
                </h2>
                <div id="collapseSeven" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                    Para transferir un bien raíz por compraventa, se necesita una escritura pública de compraventa, que debe ser inscrita en el Conservador de Bienes Raíces correspondiente.
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                        ¿Qué se requiere para otorgar un poder general?
                    </button>
                </h2>
                <div id="collapseEight" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body">
                        Para otorgar un poder general, se necesita una minuta redactada por un abogado y otorgar el documento por escritura pública en alguna Notaría.
                    </div>
                </div>
            </div>
            
        </div>
    </div>    








<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('css'); ?>

<style>

body {
    background-image: url('img/bgservicios.jpeg');
    background-size: cover;
    background-position: center;
    font-family: 'Helvetica', sans-serif;
    overflow-x: hidden;
}

.title {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: rgb(204, 204, 204);
    font-family: 'Eurostar Regular Extended', sans-serif;
    background-color: rgba(0, 0, 0, 0.5);
    padding: 10px;
    border-radius: 10px;
    font-size: 32px; /* Tamaño de fuente por defecto */
}

.box {
    width: 100%; /* Ajustar el ancho al 100% del contenedor */
    height: auto; /* Altura automática */
    margin: 10px auto; /* Margen automático */
    border: 1px solid #000;
    text-align: center;
    background-color: #ffffcc; /* Cambiar color de fondo */
    opacity: 1; /* Opacidad por defecto */
    transition: all 0.5s;
}

.box-title {
    margin-top: 20px;
    font-size: 20px; /* Tamaño de fuente por defecto */
}

.box-icon {
    width: 100%; /* Ajusta el ancho de la imagen al 100% del contenedor */
    height: auto; /* Hace que la altura se ajuste automáticamente */
    margin: 20px auto;
}

@media screen and (max-width: 600px) {
    .title {
        font-size: 24px; /* Tamaño de fuente para pantallas pequeñas */
    }

    .box {
        width: 45%; /* Ancho de caja para pantallas pequeñas */
    }
}

@media screen and (min-width: 601px) and (max-width: 992px) {
    .box {
        width: 30%; /* Ancho de caja para pantallas medianas */
    }
}


</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('javascript'); ?>
<script>

  


    </script>      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Notaria\resources\views/servicios.blade.php ENDPATH**/ ?>