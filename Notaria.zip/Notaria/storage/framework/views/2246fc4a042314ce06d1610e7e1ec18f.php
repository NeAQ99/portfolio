<?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>


<div style="background-color: #; border-radius: 10px; padding: 20px; text-align: center; margin-top: 80px;">
    <div style="display: inline-block; border: 5px solid #ffd43b; border-radius: 10px;">
        <img src="img/logo.png" alt="Logo" style="max-width: 100%; height: auto;">
    </div>
</div>




    <div class="container mb-5" style="margin-top: 50px;">
    <div class="contenedor-nosotros" style="background-color: #dbe7f5; border: 5px solid #001f3f; border-radius: 15px; padding: 20px;">
        <div class="titulo-parrafo-nosotros" style="padding-top: 20px; padding-bottom: 20px;">
            <h2>Bienvenido a la Notaría Gutiérrez</h2>
            <p>Somos una notaría de confianza ubicada en Coquimbo, Chile. Nuestra misión es proporcionar servicios notariales de alta calidad a todos nuestros clientes. Nos enorgullece ser una parte integral de nuestra comunidad, ofreciendo servicios legales esenciales a individuos, familias y empresas locales.</p>
        </div>
    </div>

    <div class="contenedor-nosotros" style="background-color: #dbe7f5; border: 5px solid #001f3f; border-radius: 15px; padding: 20px; margin-top: 20px;">
        <div class="titulo-parrafo-nosotros" style="padding-top: 20px; padding-bottom: 20px;">
            <h2>Nuestros servicios</h2>
            <p>Ofrecemos una amplia gama de servicios notariales, incluyendo: la autenticación de documentos, la preparación de escrituras, testamentos, poderes y mucho más. Nos enorgullece ofrecer un servicio personalizado y eficiente a cada uno de nuestros clientes. Nuestro equipo de profesionales capacitados está siempre listo para asistirle, ya sea que necesite ayuda con una transacción inmobiliaria, la planificación de su patrimonio o cualquier otro asunto legal.</p>
        </div>
    </div>

    <div class="contenedor-nosotros" style="background-color: #dbe7f5; border: 5px solid #001f3f; border-radius: 15px; padding: 20px; margin-top: 20px;">
        <div class="titulo-parrafo-nosotros" style="padding-top: 20px; padding-bottom: 20px;">
            <h2>Nuestro compromiso</h2>
            <p>Estamos comprometidos con la satisfacción del cliente y nos esforzamos por superar sus expectativas en cada interacción. Nuestro equipo está siempre dispuesto a ayudar y a responder a cualquier pregunta que pueda tener. Creemos en la importancia de construir relaciones duraderas con nuestros clientes, y nos esforzamos por ofrecer un servicio que no solo cumpla, sino que supere sus expectativas.</p>
        </div>
    </div>
</div>

<div style="background-color: #fff7e1; border: 2px solid #ffd43b; border-radius: 10px; padding: 20px;">
<script src="https://widget.trustmary.com/DpT-mSzD3"></script>
</div>




<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('css'); ?>


<style>
      body {
    background-image: url('img/bgservicios.jpeg');
    background-size: cover;
    background-position: center;
}

/* Configuración texto de nosotros */

#contenedor-nosotros {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.titulo-parrafo-nosotros {
    background-color: rgba(255, 255, 255, 0.7); /* Add background color with transparency */
    padding: 20px; 
    margin: 20px auto;
    border-radius: 10px;
    max-width: 80%; /* Limit maximum width to ensure readability */
}

        

    

        





    
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Notaria\resources\views/welcome.blade.php ENDPATH**/ ?>