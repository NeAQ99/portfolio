

<nav class="navbar navbar-expand-lg fixed-top" style="margin-bottom: 20px;">
    <div class="container">
        <img src="/img/Logo.png" style="width: 170px;" alt="">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #ffeb79;">
            Menu
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('/')); ?>">INICIO</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('servicios')); ?>">SERVICIOS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('quienes')); ?>">QUIENES SOMOS</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('ubicacion')); ?>">UBICACION</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contactanos')); ?>">CONTACTNOS</a>
                </li>
            </ul>
        </div>
    </div>
</nav>



<style>

.navbar-brand {
        font-size: 24px;
    }

    .navbar-nav .nav-link {
        font-size: 18px;
    }

    @media (max-width: 991.98px) {
        .navbar-brand {
            font-size: 20px;
        }

        .navbar-nav .nav-link {
            font-size: 16px;
        }
    }
    .navbar {
        background-color: #001f3f; /* Color de fondo azul marino */
    }

    .navbar-brand {
        color: #ffeb79; /* Color de texto amarillo pastel */
        text-shadow: 2px 2px 2px #blue; /* Sombra de texto color blanco */
        font-weight: bold; /* Hacer el texto más grueso */
        font-size: 36px; 
    }

    .navbar-nav .nav-link {
        color: #ffffcc; /* Color de texto amarillo pastel */
        text-shadow: 2px 2px 2px #fff; /* Sombra de texto color blanco */
        font-weight: bold; /* Hacer el texto más grueso */
        font-size:    24px;
    }

    .navbar-light {
        color: #fff; /* Color de texto blanco */
        font-size: 25px;
        text-transform: uppercase;
        font-weight: bold;
        letter-spacing: 2px;
    }

    .navbar-light .navbar-nav .active > .nav-link,
    .navbar-light .navbar-nav .nav-link.active,
    .navbar-light .navbar-nav .nav-link.show,
    .navbar-light .navbar-nav .show > .nav-link {
        color: #fff; /* Color de texto blanco */
    }




    .navbar-nav {
        text-align: center;
    }

    .nav-link {
        padding: .2rem 1rem;
    }

    .nav-link.active,
    .nav-link:focus {
        color: #fff; /* Color de texto blanco */
    }

   

    .navbar-light .navbar-nav .nav-link:focus,
    .navbar-light .navbar-nav .nav-link:hover {
        color: #fff; /* Color de texto blanco */
    }


</style>
<?php /**PATH C:\xampp\htdocs\Notaria\resources\views/layouts/top.blade.php ENDPATH**/ ?>