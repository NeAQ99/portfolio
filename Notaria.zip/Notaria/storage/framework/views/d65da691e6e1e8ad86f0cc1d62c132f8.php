

<?php echo $__env->make('layouts.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<!-- Div del notario --------------------------------------------------------------------------------------------------------------------->

<div class="" style="background-color: rgb(36,64,101); align-items: center; display: flex; justify-content: center; text-align: center; margin-top: 50px;">
    <h1 id="el-titulo-de-notario" style="padding-bottom: 50px; padding-top: 50px; color: rgb(204,204,204); font-family: 'Eurostar Regular Extended', sans-serif;">Nuestro Notario</h1>
</div>

<div id="seccion-notario" style="padding-bottom: 70px; padding-top: 20px; position: relative;">        

    <video autoplay muted loop style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
        <source src="video/video1.mp4" type="video/mp4">
        <!-- Agrega aquí más fuentes de video si lo deseas -->
        Tu navegador no admite videos HTML5.
    </video>

    <div class="container" style="display: flex; flex-direction: column; justify-content: center; align-items: center; background-size: cover; position: relative; z-index: 1;">            
        <div style="text-align: center; margin-bottom: 20px; background-color: rgba(0, 0, 0, 0.6); padding: 20px; border: 2px solid rgb(255,226,121); color: white;">
            <h5 id="texto_profesional">
                Patricio Andres Gutierrez Gajardo inició su formación académica en la Universidad Católica del Norte, sede Coquimbo, culminando con honores. La trayectoria continuó con un Máster en Dirección y Gestión Tributaria en la Universidad Adolfo Ibañez, reafirmando el compromiso con la excelencia académica.                </h5>
        </div>
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="img/elnotario2.png" alt="Imagen Superpuesta" style="max-width: 100%; max-height: 500px; border-radius: 15px; border: 2px solid rgb(255,226,121);">
        </div>
        <div style="text-align: center; background-color: rgba(0, 0, 0, 0.6); padding: 20px; border: 2px solid rgb(255,226,121); color: white;">
            <h5 id="texto_profesional">
                El 10 de septiembre de 2021, mediante el decreto número 103 emitido por el Ministerio de Justicia y Derechos Humanos, se nombró a Patricio Andres Gutierrez Gajardo como notario titular de la Sexta Notaría de Coquimbo. Además, forma parte de la Asociación de Notarios y Conservadores de Chile, participando en el desarrollo de la profesión notarial en el país.                </h5>
        </div>
    </div>

</div>


<!-- Fin seccion notario ------------------------------------------------------------------------------------------------------------------>

<!-- Seccion mensaje profesional ---------------------------------------------------------------------------------------------------------->

<div class="mt-4 mb-4">
<div id="contenedor" style="background-color:rgba(36,64,101, 0.5); display: flex; align-items: center; justify-content: center;">
    <div style="background-color: rgba(0, 0, 0, 0.5); padding: 20px; text-align: center;">
    <p style="color: rgb(204,204,204); margin: 0;">
        Nuestro conjunto se distingue por proporcionar un servicio individualizado, <br>orientando y suministrando todos los datos que nuestros clientes necesiten para la adecuada ejecución de sus trámites, <br>subrayando así nuestro compromiso con la Región de Coquimbo.</p>
    <img src="img/Icono.png" style="width: 50px; height: 50px; margin-top: 20px;">
    <p style="color: rgb(255,226,121); margin: 0; padding-top:10px">
        - Notaria Gutierrez -</p>
    </div>
</div>
</div>

<div id="galeria-instalaciones" class="container mt-8" style="margin-top:50px;">
        <h2 style="padding-bottom:30px;">Nuestras instalaciones</h2>
        <div id="carouselExample" class="carousel slide">
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img src="img/Prueba1.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/NotariaRemake.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/instalacion1.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/Frontis.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/otrointerior.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/favoritalado.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
                <div class="carousel-item">
                <img src="img/yotrolado.png" class="d-block w-100" alt="..." style="border-radius: 25px;">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>        
    </div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('css'); ?>
<style>
    

    #galeria-instalaciones {
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    background-color: #ffeb79;
    padding: 20px;
    margin: 20px auto;
    border-radius: 10px;
}

.carousel-item img {
    height: 70vh;
}

@font-face {
    font-family: 'Eurostar Regular Extended';
    src: url('/fonts/Eurostar/eurostarregularextended.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
}

body {
    font-family: 'Helvetica', sans-serif;
    overflow-x: hidden;
    background-image: url('img/bgservicios.jpeg');
    background-size: cover;
    background-position: center;
}

.title {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: rgb(204, 204, 204);
    font-family: 'Eurostar Regular Extended', sans-serif;
    background-color: rgba(0, 0, 0, 0.5);
    padding: 10px;
    border-radius: 10px;
}

/* Configuracion de la seccion de notario */
#seccion-notario {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
}

/* Configuracion del mensaje PROFESIONAL */
.parallax {
    background-image: url("img/2/24.JPG");
    min-height: 50vh;
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}

#contenedor-parallax {
    height: 50vh;
    font-size: 30px;
}

/* Media Queries */
@media screen and (max-width: 1000px) {
    .title {
        font-size: 14px;
    }
}

@media screen and (max-width: 800px) {
    .title {
        font-size: 12px;
    }
}

@media screen and (max-width: 600px) {
    .title p{
        font-size: 10px;
    }
     #contenedor {
        font-size: 24px;
    }
    
}

@media screen and (max-width: 300px) {
    .title {
        font-size: 8px;
    }
   
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Notaria\resources\views/quienes.blade.php ENDPATH**/ ?>