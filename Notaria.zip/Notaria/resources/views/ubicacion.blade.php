@extends('layouts.app')
@include('layouts.top')
@section('content')    

    <!-- Mapa con ubicacion de la notaria --------------------------------------------------------------------------------------------------------->

    <div class="mt-5" id="contenedor-Mapa" style="background-image: url(img/notaria1.jpg); background-size: cover; color: black; padding-top:50px; text-align: center;">

        <h1 style="color:white; background-color: rgba(0,0,0,0.5); border-radius: 10px; padding: 20px; display: inline-block;">Dirección de Nuestro Establecimiento</h1>

        <p style="color:white; background-color: rgba(0,0,0,0.5); border-radius: 10px; padding: 20px;">Nuestra notaría, ubicada a pasos del centro de la ciudad, ofrece un servicio rápido y eficiente en un lugar estratégicamente situado.”
            <br>Disfrute de la comodidad de realizar sus trámites notariales en un corto tiempo, sin largas esperas.</p>

        <div class="container" style="margin-top: 50px; padding-bottom: 50px;">        
            <iframe id="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3456.6346583630566!2d-71.340929!3d-29.961185600000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9691c9a8963c7665%3A0x92cbe94fcaca2bb0!2sNOTARIA%20PATRICIO%20GUTIERREZ%20GAJARDO!5e0!3m2!1ses-419!2scl!4v1707316444649!5m2!1ses-419!2scl" style="border:5px solid rgb(255,226,121); border-radius:15px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

    </div>

    <!-- Fin de mapa con ubicacion de la notaria --------------------------------------------------------------------------------------------------> 

@include('layouts.footer')
@endsection

@section('css')
@parent
    
    <style>

        @font-face {

            font-family: 'Eurostar Regular Extended';
            src: url('/fonts/Eurostar/eurostarregularextended.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;

        }




        /* Configuracion del mapa/ubicacion */

        @font-face {
            font-family: 'Eurostar Regular Extended';
            src: url('/fonts/Eurostar/eurostarregularextended.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        body {
            font-family: 'Helvetica', sans-serif;
            overflow-x: hidden;
            background-image: url('img/bgservicios.jpeg');
            background-size: cover;
            background-position: center;
        }          

        .title {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: rgb(204,204,204);
            font-family: 'Eurostar Regular Extended', sans-serif;
            background-color: rgba(0, 0, 0, 0.5);
            padding: 10px;
            
            max-width: 90%; /* Added max-width for responsiveness */
        }            

        /* Configuracion del mapa/ubicacion */

        #mapa{
            width: 100%; /* Change width to 100% for responsiveness */
            height: 650px;
        }    

        /* Media queries for responsive design */

        @media screen and (max-width: 600px) {                              
            .title {
                font-size: 24px; /* Adjust font size for smaller screens */
            }              
            #mapa {
                height: 400px; /* Adjust height for smaller screens */
            }
        }

        @media screen and (min-width: 601px) and (max-width: 992px) {                            
            .title {
                font-size: 32px; /* Adjust font size for medium screens */
            }           
            #mapa {
                height: 500px; /* Adjust height for medium screens */
            }
        }

    </style>
@endsection