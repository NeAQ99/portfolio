@extends('layouts.app')
@include('layouts.top')
@section('content')


<div class="msgConfianza text-center py-5 mt-4" style="background-image: url(img/tranquilidad4.png); background-size: cover;">        
        <div class="texto-confianza">
            <h1>Queremos que realice sus trámites de manera rápida y cómoda</h1>
        </div>
    </div>
<!-- Div para contener toda la información de contacto ---------------------------------------------------------------------------------------->  

 <div id="seccion-contacto" class="text-center py-5" style="background-image: url(img/contactofondo.png); background-size: cover; color: black;">
        
        <h1 style="color:white; background-color: rgba(0,0,0,0.5); border-radius: 10px; padding: 20px;">Contáctanos!</h1>        
      
        <div class="d-flex flex-wrap justify-content-around" style="color:white; background-color: rgba(0,0,0,0.5); border-radius: 10px; padding: 20px;">

            <!-- Parte izquierda donde va la información de contacto -->

            <div class="p-3" style="flex: 1 0 21rem; max-width: 21rem; line-height: 1.6;">                
                <h2><br>HORARIO:</h2>
                <br>
                <p>LUNES A VIERNES: 8:30 a 17:00 hrs. (CONTINUADO)</p>              
                <p>SÁBADO: 10:00 a 13:00 hrs. <br> (SOLO DÍAS DE TURNO)</p>         
                <br><br>             
                <h2>TELÉFONOS:</h2>
                <br>
                <p>(51) 277 5787</p>  
                
                <p>(51) 277 5788</p>              
            </div>

            <!-- Parte derecha donde va el formulario de contacto por email -->

            <div class="p-3" style="flex: 1 0 21rem; max-width: 28rem;">                
                <form action="https://formsubmit.co/contacto@notariapgutierrez.cl" method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="subject" class="form-label">Asunto</label>
                        <input type="text" class="form-control" id="subject" name="subject">
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Mensaje</label>
                        <textarea class="form-control" id="message" name="comments"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="background-color: rgb(255,226,121); color: black;">ENVIAR</button>

                    <input type="hidden" name="_next" value="http://127.0.0.1:8000/">
                    <input type="hidden" name="_captcha" value="false">
                </form>
            </div>
        </div>
    </div>    
@include('layouts.footer')
    <!-- Fin de seccion de contacto y fin de la pagina -->      
@endsection

@section('css')  
@parent
<style>
    body {
            background-image: url('img/bgservicios.jpeg');
            background-size: cover;
            background-position: center;
        }

        /* Configuración de la imagen en el mensaje de confianza */
        .msgConfianza {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 480px;
        }

        /* Configuración del texto en el mensaje de confianza */
        .texto-confianza {
            background-color: rgba(0, 0, 0, 0.5); 
            color: white; 
            padding: 10px; 
            border-radius: 10px;
            opacity: 0;
        }

        /* Media queries para hacer el diseño responsive */
        @media (max-width: 768px) {
            .msgConfianza {
                height: auto;
            }

            .texto-confianza {
                opacity: 1;
            }
        }

        
</style>
@endsection
