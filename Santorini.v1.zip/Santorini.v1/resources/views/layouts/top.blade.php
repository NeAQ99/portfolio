
<style>
 
  #word-display {
    font-size: 48px;
    font-family: Arial, sans-serif;
    text-align: center;
    color: white; /* Cambiar el color del texto a blanco */
        text-shadow: 2px 2px 4px black; /* Agregar sombra a las palabras */
    background-color: #1e73ba;
  }
</style>



<div id="word-display"></div>


<script>
  // Array de palabras
    var palabras = [
    "Pastas",
    "carnes",
    "mariscos",
    "pescados",
    "cocktails"
 
    ];

  // Función para generar palabra aleatoria
    function generateRandomWord() {
    var randomIndex = Math.floor(Math.random() * palabras.length);
    var randomWord = palabras[randomIndex];
    document.getElementById("word-display").innerText = randomWord;
    }

  // Cambiar la palabra automáticamente cada 3 segundos
    setInterval(generateRandomWord, 3000);

  // Generar palabra aleatoria al cargar la página
    generateRandomWord();
</script>