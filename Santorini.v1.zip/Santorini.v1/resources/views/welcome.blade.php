@extends('layouts.app')

@section('content')
@include('layouts.top')


<!-- Hero -->
<section class="et-hero-tabs text-white" style="background-image: url('img/bg.jpeg'); background-size: cover; position: relative;">
    <img src="img/iconoredondeado.png" alt="Imagen" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 1; width: 700px;">
    
    <div class="et-hero-tabs-container">
        <a class="et-hero-tab" href="#tab-carta">Carta</a> 
        <a class="et-hero-tab" href="#tab-anuncios">Anuncios y Eventos</a>
        <a class="et-hero-tab" href="#tab-ubicacion">Ubicacion</a>
        <a class="et-hero-tab" href="#tab-quienes">Quienes Somos</a>
        <a class="et-hero-tab" href="#tab-reserva">Reservas</a>
    </div>
</section>



<!-- Main -->
<main class="et-main">
    <secti style:"bg-color"; class="et-slide" id="tab-carta">


    </section>
    <section class="et-slide" id="tab-anuncios">
        <h1>Anuncios y Eventos</h1>
        
    </section>
    <section class="et-slide" id="tab-ubicacion">
        <h1>Ubicacion</h1>
    
    </section>
    <section class="et-slide" id="tab-quienes">
        <h1>Quienes Somos</h1>
    </section>
    <section class="et-slide" id="tab-reserva">
        <h1>Reserva</h1>
    </section>
    
</main>
@include('layouts.footer')
@endsection

@section('css')
@parent

<style>
    body {
        font-family: "Century Gothic", "Lato", sans-serif;
    }

    a {
        text-decoration: none;
    }

    .et-hero-tabs,
    .et-slide {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100vh;
        position: relative;
        background: #eee;
        text-align: center;
        padding: 0 2em;
        h1 {
            font-size: 2rem;
            margin: 0;
            letter-spacing: 1rem;
        }
        h3 {
            font-size: 1rem;
            letter-spacing: 0.3rem;
            opacity: 0.6;
        }
    }

    .et-hero-tabs-container {
        display: flex;
        flex-direction: row;
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 70px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        background:#1e73ba;
        z-index: 10;
        &--top {
            position: fixed;
            top: 0;
        }
    }

    .et-hero-tab {
        display: flex;
        justify-content: center;
        align-items: center;
        flex: 1;
        color: #000;
        letter-spacing: 0.1rem;
        transition: all 0.5s ease;
        font-size: 0.8rem;
        &:hover {
            color: white;
            background: rgba(102, 177, 241, 0.8);
            transition: all 0.5s ease;
        }
    }

    .et-hero-tab-slider {
        position: absolute;
        bottom: 0;
        width: 0;
        height: 6px;
        background: #66b1f1;
        transition: left 0.3s ease;
    }

    @media (min-width: 800px) {
        .et-hero-tabs,
        .et-slide {
            h1 {
                font-size: 3rem;
            }
            h3 {
                font-size: 1rem;
            }
        }
        .et-hero-tab {
            font-size: 1rem;
        }
    }




</style>

    

@endsection


@section('scripts')
@parent

<script>
    class StickyNavigation {
	
	constructor() {
		this.currentId = null;
		this.currentTab = null;
		this.tabContainerHeight = 70;
		let self = this;
		$('.et-hero-tab').click(function() { 
			self.onTabClick(event, $(this)); 
		});
		$(window).scroll(() => { this.onScroll(); });
		$(window).resize(() => { this.onResize(); });
	}
	
	onTabClick(event, element) {
		event.preventDefault();
		let scrollTop = $(element.attr('href')).offset().top - this.tabContainerHeight + 1;
		$('html, body').animate({ scrollTop: scrollTop }, 600);
	}
	
	onScroll() {
		this.checkTabContainerPosition();
    this.findCurrentTabSelector();
	}
	
	onResize() {
		if(this.currentId) {
			this.setSliderCss();
		}
	}
	
	checkTabContainerPosition() {
		let offset = $('.et-hero-tabs').offset().top + $('.et-hero-tabs').height() - this.tabContainerHeight;
		if($(window).scrollTop() > offset) {
			$('.et-hero-tabs-container').addClass('et-hero-tabs-container--top');
		} 
		else {
			$('.et-hero-tabs-container').removeClass('et-hero-tabs-container--top');
		}
	}
	
	findCurrentTabSelector(element) {
		let newCurrentId;
		let newCurrentTab;
		let self = this;
		$('.et-hero-tab').each(function() {
			let id = $(this).attr('href');
			let offsetTop = $(id).offset().top - self.tabContainerHeight;
			let offsetBottom = $(id).offset().top + $(id).height() - self.tabContainerHeight;
			if($(window).scrollTop() > offsetTop && $(window).scrollTop() < offsetBottom) {
				newCurrentId = id;
				newCurrentTab = $(this);
			}
		});
		if(this.currentId != newCurrentId || this.currentId === null) {
			this.currentId = newCurrentId;
			this.currentTab = newCurrentTab;
			this.setSliderCss();
		}
	}
	
	setSliderCss() {
		let width = 0;
		let left = 0;
		if(this.currentTab) {
			width = this.currentTab.css('width');
			left = this.currentTab.offset().left;
		}
		$('.et-hero-tab-slider').css('width', width);
		$('.et-hero-tab-slider').css('left', left);
	}
	
}

new StickyNavigation();
</script>
@endsection